import { Router } from "express";
import {
  getAllRooms,
  addRoom,
  getRoomsByHotel,
  getRoomById,
  updateRoom,
  deleteRoom,
} from "../controllers/room.controller.js";
import { requireClerkAuth, loadUser, authorizeRoles } from "../middlewares/auth.middleware.js";
import { upload } from "../middlewares/multer.middleware.js";

const router = Router();

// public routes
router.route("/").get(getAllRooms); // NEW — all rooms across every approved hotel
router.route("/hotel/:hotelId").get(getRoomsByHotel);
router.route("/:roomId").get(getRoomById);

// secured routes — hotel owner only
router
  .route("/hotel/:hotelId")
  .post(
    requireClerkAuth, loadUser,
    authorizeRoles("hotel_owner"),
    upload.array("images", 5),
    addRoom
  );
router
  .route("/:roomId")
  .patch(requireClerkAuth, loadUser, authorizeRoles("hotel_owner"), updateRoom)
  .delete(requireClerkAuth, loadUser, authorizeRoles("hotel_owner"), deleteRoom);

export default router;
